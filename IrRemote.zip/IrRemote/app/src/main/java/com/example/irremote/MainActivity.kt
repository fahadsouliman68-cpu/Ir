package com.example.irremote

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

data class Screen(val name: String, val proto: Proto, val addr: Int, val table: MutableMap<String, Int>)

class MainActivity : Activity() {
    private lateinit var ir: Ir
    private val handler = Handler(Looper.getMainLooper())
    private val screens = ArrayList<Screen>()
    private val delayMs = 1200L

    private val colBg = Color.parseColor("#0E1117")
    private val colCard = Color.parseColor("#1C2230")
    private val colKey = Color.parseColor("#262E3F")
    private val colAccent = Color.parseColor("#4F8CFF")
    private val colRed = Color.parseColor("#E5484D")
    private val colSub = Color.parseColor("#8A94A6")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = Ir(this)
        load()
        showHome()
    }

    // ---------- UI helpers ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun shape(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun pill(s: String, color: Int = colAccent, onClick: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = shape(color, 14)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(6), 0, dp(6)) }
        setOnClickListener { onClick() }
    }

    private fun weight(v: View) = v.apply {
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
    }

    private fun key(caption: String, k: String, s: Screen, size: Int = 64, color: Int = colKey): TextView =
        TextView(this).apply {
            text = caption
            textSize = if (size >= 80) 20f else 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = shape(color, size / 2)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
                .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            setOnClickListener {
                val code = s.table[k]
                if (code == null) toast("الزر غير محدد. اضغط عليه مطولاً لتحديده")
                else ir.send(Code(s.proto, s.addr, code))
            }
            setOnLongClickListener { finder(s, k, caption); true }
        }

    private fun hrow(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        v.forEach { addView(it) }
    }

    private fun vcol(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        v.forEach { addView(it) }
    }

    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundColor(colBg)
        setPadding(dp(20), dp(24), dp(20), dp(24))
    }

    private fun setPage(v: LinearLayout) {
        handler.removeCallbacksAndMessages(null)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(colBg)
            addView(v)
        })
    }

    // ---------- storage ----------
    private fun save() {
        val arr = JSONArray()
        for (s in screens) {
            arr.put(
                JSONObject().put("name", s.name).put("proto", s.proto.name).put("addr", s.addr)
                    .put("table", JSONObject(s.table as Map<*, *>))
            )
        }
        getSharedPreferences("ir", MODE_PRIVATE).edit().putString("screens", arr.toString()).apply()
    }

    private fun load() {
        screens.clear()
        val arr = JSONArray(getSharedPreferences("ir", MODE_PRIVATE).getString("screens", "[]") ?: "[]")
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            val t = o.getJSONObject("table")
            val m = mutableMapOf<String, Int>()
            for (k in t.keys()) m[k] = t.getInt(k)
            screens.add(Screen(o.getString("name"), Proto.valueOf(o.getString("proto")), o.getInt("addr"), m))
        }
    }

    // ---------- pages ----------
    private fun showHome() {
        val r = root()
        r.addView(label("ريموت الشاشات", 26f, true))
        r.addView(label("اختر شاشة", 14f, false, colSub))
        if (!ir.available()) r.addView(label("⚠ هذا الهاتف لا يحتوي باعث IR", 14f, true, colRed))
        for (s in screens) {
            r.addView(TextView(this).apply {
                text = "📺  ${s.name}"
                textSize = 18f
                setTextColor(Color.WHITE)
                background = shape(colCard, 16)
                setPadding(dp(20), dp(22), dp(20), dp(22))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(8), 0, dp(8)) }
                setOnClickListener { showRemote(s) }
            })
        }
        r.addView(pill("＋  إضافة شاشة") { askName() })
        setPage(r)
    }

    private fun askName() {
        val et = EditText(this).apply { hint = "مثال: شاشة غرفة النوم" }
        AlertDialog.Builder(this)
            .setTitle("اسم الشاشة")
            .setView(et)
            .setPositiveButton("التالي") { _, _ ->
                startAdd(et.text.toString().ifBlank { "شاشة ${screens.size + 1}" })
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun startAdd(name: String) {
        scanner(
            title = "ابحث عن زر التشغيل",
            list = Brands.list,
            extra = {
                scanner(
                    title = "بحث موسّع",
                    list = Brands.extended(),
                    extra = null,
                    onSave = { c -> saveNew(name, c) },
                    onCancel = { showHome() }
                )
            },
            onSave = { c -> saveNew(name, c) },
            onCancel = { showHome() }
        )
    }

    private fun saveNew(name: String, c: Candidate) {
        val table = if (c.table.isNotEmpty()) c.table.toMutableMap() else mutableMapOf("power" to c.cmd)
        val s = Screen(name, c.proto, c.addr, table)
        screens.add(s)
        save()
        showRemote(s)
    }

    private fun showRemote(s: Screen) {
        val r = root()
        r.addView(TextView(this).apply {
            text = "‹  رجوع"
            textSize = 16f
            setTextColor(colAccent)
            setPadding(0, 0, 0, dp(8))
            setOnClickListener { showHome() }
        })
        r.addView(label(s.name, 22f, true))
        r.addView(label("اضغط مطولاً على أي زر لتحديده", 12f, false, colSub))

        r.addView(key("⏻", "power", s, 92, colRed))
        r.addView(hrow(
            key("المصدر", "source", s, 80),
            key("كتم", "mute", s, 80),
            key("القائمة", "menu", s, 80)
        ))
        r.addView(hrow(
            vcol(label("صوت", 12f, false, colSub), key("+", "volup", s), key("−", "voldown", s)),
            vcol(
                key("▲", "up", s),
                hrow(key("◀", "left", s), key("OK", "ok", s, 64, colAccent), key("▶", "right", s)),
                key("▼", "down", s)
            ),
            vcol(label("قناة", 12f, false, colSub), key("+", "chup", s), key("−", "chdown", s))
        ))
        r.addView(hrow(key("↩", "back", s), key("⌂", "home", s)))
        r.addView(pill("🗑  حذف الشاشة", colRed) { confirmDelete(s) })
        setPage(r)
    }

    private fun confirmDelete(s: Screen) {
        AlertDialog.Builder(this)
            .setTitle("حذف ${s.name}؟")
            .setPositiveButton("حذف") { _, _ -> screens.remove(s); save(); showHome() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun finder(s: Screen, keyName: String, caption: String) {
        if (s.proto.maxCmd < 0) { toast("لا يمكن تحديد أزرار هذه الشاشة"); return }
        val cands = (0..s.proto.maxCmd).map { Candidate("زر «$caption» — أمر $it", s.proto, s.addr, it) }
        scanner(
            title = "حدد زر «$caption»",
            list = cands,
            extra = null,
            onSave = { c -> s.table[keyName] = c.cmd; save(); showRemote(s) },
            onCancel = { showRemote(s) }
        )
    }

    // ---------- scanner ----------
    private fun scanner(
        title: String,
        list: List<Candidate>,
        extra: (() -> Unit)?,
        onSave: (Candidate) -> Unit,
        onCancel: () -> Unit
    ) {
        var i = 0
        var auto = false
        val counter = label("اضغط تشغيل تلقائي", 18f, true)
        val play = pill("▶  تشغيل تلقائي") {}

        fun show() {
            counter.text = "${list[i].label}\n${i + 1} / ${list.size}"
            ir.send(list[i].code())
        }

        val tick = object : Runnable {
            override fun run() {
                if (!auto) return
                if (i < list.size - 1) {
                    i++
                    show()
                    handler.postDelayed(this, delayMs)
                } else {
                    auto = false
                    play.text = "▶  تشغيل تلقائي"
                    counter.text = "انتهت القائمة"
                }
            }
        }

        fun stopAuto() {
            auto = false
            handler.removeCallbacks(tick)
            play.text = "▶  تشغيل تلقائي"
        }

        play.setOnClickListener {
            if (auto) stopAuto() else {
                auto = true
                play.text = "⏸  إيقاف"
                show()
                handler.postDelayed(tick, delayMs)
            }
        }

        val r = root()
        r.addView(label(title, 20f, true))
        r.addView(label("وجّه الهاتف نحو الشاشة، وعند الاستجابة الصحيحة اضغط ✅", 13f, false, colSub))
        r.addView(counter)
        r.addView(play)
        r.addView(hrow(
            weight(pill("⏮ السابق", colKey) { stopAuto(); if (i > 0) i--; show() }),
            weight(pill("التالي ⏭", colKey) { stopAuto(); if (i < list.size - 1) i++; show() })
        ))
        r.addView(pill("✅  هذا هو الصحيح") { stopAuto(); onSave(list[i]) })
        if (extra != null) r.addView(pill("🔎  بحث موسّع (شركة غير معروفة)", colKey) { stopAuto(); extra() })
        r.addView(pill("إلغاء", colKey) { stopAuto(); onCancel() })
        setPage(r)
    }
}
