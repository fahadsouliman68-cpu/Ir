package com.example.irremote

import android.content.Context
import android.hardware.ConsumerIrManager

enum class Proto(val maxCmd: Int) { NEC(255), SAMSUNG(255), SONY12(127), RC5(63), PANA(-1) }

data class Code(val proto: Proto, val addr: Int, val cmd: Int)

class Frame(val freq: Int, val pattern: IntArray)

data class Candidate(
    val label: String,
    val proto: Proto,
    val addr: Int,
    val cmd: Int,
    val table: Map<String, Int> = emptyMap()
) {
    fun code() = Code(proto, addr, cmd)
}

class Ir(ctx: Context) {
    private val mgr = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    fun available() = mgr?.hasIrEmitter() == true
    fun send(c: Code) {
        try {
            val f = IrCodes.encode(c)
            mgr?.transmit(f.freq, f.pattern)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

object IrCodes {
    private var toggle = 0

    private fun lsb(v: Int, n: Int): List<Int> = (0 until n).map { (v shr it) and 1 }
    private fun msb(v: Long, n: Int): List<Int> = (n - 1 downTo 0).map { ((v shr it) and 1L).toInt() }

    fun encode(c: Code): Frame = when (c.proto) {
        Proto.NEC -> nec(9000, 4500, listOf(c.addr and 255, c.addr.inv() and 255, c.cmd and 255, c.cmd.inv() and 255))
        Proto.SAMSUNG -> nec(4500, 4500, listOf(c.addr and 255, c.addr and 255, c.cmd and 255, c.cmd.inv() and 255))
        Proto.SONY12 -> sony(c.addr, c.cmd)
        Proto.RC5 -> rc5(c.addr, c.cmd)
        Proto.PANA -> pana(c.addr, c.cmd)
    }

    private fun nec(h1: Int, h2: Int, bytes: List<Int>): Frame {
        val p = ArrayList<Int>()
        p.add(h1); p.add(h2)
        for (b in bytes) for (bit in lsb(b, 8)) {
            p.add(560)
            p.add(if (bit == 1) 1690 else 560)
        }
        p.add(560); p.add(40000)
        return Frame(38000, p.toIntArray())
    }

    private fun sony(addr: Int, cmd: Int): Frame {
        val one = ArrayList<Int>()
        one.add(2400); one.add(600)
        for (b in lsb(cmd, 7) + lsb(addr, 5)) {
            one.add(if (b == 1) 1200 else 600)
            one.add(600)
        }
        val total = one.sum()
        one[one.size - 1] = one[one.size - 1] + (45000 - total)
        val all = ArrayList<Int>()
        repeat(3) { all.addAll(one) }
        return Frame(40000, all.toIntArray())
    }

    private fun rc5(addr: Int, cmd: Int): Frame {
        toggle = toggle xor 1
        val bits = ArrayList<Int>()
        bits.add(1); bits.add(if (cmd < 64) 1 else 0); bits.add(toggle)
        for (i in 4 downTo 0) bits.add((addr shr i) and 1)
        for (i in 5 downTo 0) bits.add((cmd shr i) and 1)
        val lv = ArrayList<Boolean>()
        for (b in bits) {
            if (b == 1) { lv.add(false); lv.add(true) } else { lv.add(true); lv.add(false) }
        }
        while (lv.isNotEmpty() && !lv[0]) lv.removeAt(0)
        val p = ArrayList<Int>()
        var cur = lv[0]
        var run = 0
        for (x in lv) {
            if (x == cur) run += 889 else { p.add(run); cur = x; run = 889 }
        }
        p.add(run)
        if (cur) p.add(40000)
        return Frame(36000, p.toIntArray())
    }

    private fun pana(addr: Int, data: Int): Frame {
        val p = ArrayList<Int>()
        p.add(3456); p.add(1728)
        val bits = msb(addr.toLong() and 0xFFFFL, 16) + msb(data.toLong() and 0xFFFFFFFFL, 32)
        for (b in bits) {
            p.add(432)
            p.add(if (b == 1) 1296 else 432)
        }
        p.add(432); p.add(40000)
        return Frame(37000, p.toIntArray())
    }
}

object Brands {
    private fun brand(label: String, proto: Proto, addr: Int, table: Map<String, Int>) =
        Candidate(label, proto, addr, table.getValue("power"), table)

    val list: List<Candidate> = listOf(
        brand("Samsung", Proto.SAMSUNG, 7, mapOf("power" to 2, "volup" to 7, "voldown" to 11, "mute" to 15, "chup" to 18, "chdown" to 16, "source" to 1)),
        brand("LG", Proto.NEC, 4, mapOf("power" to 8, "volup" to 2, "voldown" to 3, "mute" to 9, "chup" to 0, "chdown" to 1, "source" to 11)),
        brand("Sony", Proto.SONY12, 1, mapOf("power" to 21, "volup" to 18, "voldown" to 19, "mute" to 20, "chup" to 16, "chdown" to 17, "source" to 37)),
        brand("Philips (RC5)", Proto.RC5, 0, mapOf("power" to 12, "volup" to 16, "voldown" to 17, "mute" to 13, "chup" to 32, "chdown" to 33)),
        brand("Panasonic", Proto.PANA, 0x4004, mapOf("power" to 0x0100BCBD)),
        brand("Toshiba", Proto.NEC, 2, mapOf("power" to 0x48))
    )

    private val necPowerCmds = listOf(0x08, 0x02, 0x12, 0x48, 0x0C, 0x1C, 0x40, 0x45, 0x01, 0x00, 0x10, 0x15)

    fun extended(): List<Candidate> = (0..255).flatMap { a ->
        necPowerCmds.map { c -> Candidate("NEC عنوان $a — أمر $c", Proto.NEC, a, c) }
    }
}
