خطوات بناء الـ APK:
1) ثبّت Android Studio (مجاني) من developer.android.com/studio
2) افتح البرنامج > Open > اختر مجلد IrRemote وانتظر انتهاء Sync
3) من القائمة: Build > Build Bundle(s)/APK(s) > Build APK(s)
4) ستجد الملف في: app/build/outputs/apk/debug/app-debug.apk
5) انقله إلى الهاتف وثبّته (فعّل "التثبيت من مصادر غير معروفة")
